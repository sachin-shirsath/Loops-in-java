
class Loop9{
	public static void main(String[]args){
		//for loop
		/*for(int counter = 0 ;counter<10001;counter++){
		System.out.println(counter);}*/
		//while loop
		int a=0;
		/*while(a<100){
			System.out.println(a);
		a=a+2;}*/
		do{System.out.println(a);
		a=a+1;}
		while(a<11);
			
	}
}
			